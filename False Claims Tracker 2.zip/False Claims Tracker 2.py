import tkinter as tk ##importing tkinter library with alias tk
from tkinter import messagebox

# Function to open a new window for entering a new claim
def open_new_claim_window():
    new_claim_window = tk.Tk()  # Create a new window
    new_claim_window.title("New Claim Window")   # Added widgets for entering new claim details

    agent_form_btn = tk.Button(new_claim_window, text="Form", command=open_agent_form)
    agent_form_btn.pack()

def open_view_claims_window():  # Fucntion to open a new window for viewing existing claims
    view_claims_window = tk.Tk()  # Create a new window
    view_claims_window.title("View Claims Window")  # Added widgets for viewing existing claims
    

def open_additional_info_window(): # Function to open a new window for displaying additional information
    additional_info_window = tk.Tk()  # Create a new window
    additional_info_window.title("Additional Information Window")   # Added widgets for displaying additional information
   
# Function to open a new window for agent form
def open_agent_form():  # Create a new window 
    agent_form_window = tk.Tk()
    agent_form_window.title("Agent Form Window")  # Input for agent form
  
# Function to handle forward action
def forward_action(label):
    label.config(text="Moving forward...")

# Function to handle back action
def back_action(label):
    label.config(text="Moving back...")

# Function to exit the application
def exit_application(window):
    if messagebox.askokcancel("Exit Confirmation", "Are you sure you want to exit the application?"):
        window.destroy()

# Create the main window
window = tk.Tk()
window.title("False Delivery Claims Tracker")

# Main window components
label_welcome = tk.Label(window, text="Welcome to False Delivery Claims Tracker", font=("Arial Black", 20))
label_welcome.pack(pady=10)  # Creating a label widget to display the welcome result

new_claim_button = tk.Button(window, text="Enter New Claim", command=open_new_claim_window)
new_claim_button.pack(side="top", pady=5)

view_claims_button = tk.Button(window, text="View Existing Claims", command=open_view_claims_window)
view_claims_button.pack(side="top", pady=5)

additional_info_button = tk.Button(window, text="Additional Information", command=open_additional_info_window)
additional_info_button.pack(side="top", pady=5)

forward_button = tk.Button(window, text="Forward", command=lambda: forward_action(label_status))
forward_button.pack(side="left", padx=5)

back_button = tk.Button(window, text="Back", command=lambda: back_action(label_status))
back_button.pack(side="left", padx=5)                                                                                      

label_status = tk.Label(window, text="", font=("Arial", 12))
label_status.pack(pady=10)

exit_button = tk.Button(window, text="Exit", command=lambda: exit_application(window))
exit_button.pack(side="bottom", pady=10)

window.mainloop()  # Running the main loop to display the window and handle user interactions
    
